package br.com.fiap.buscheck.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.fiap.buscheck.dto.SignupDTO;
import br.com.fiap.buscheck.dto.UserDTO;
import br.com.fiap.buscheck.dto.UserIdDTO;
import br.com.fiap.buscheck.model.LoginModel;
import br.com.fiap.buscheck.model.UserModel;
import br.com.fiap.buscheck.repository.LoginRepository;
import br.com.fiap.buscheck.repository.UserRepository;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private LoginRepository loginRepository;

    public UserIdDTO save(SignupDTO newUser) {
        
        UserModel userModel = new UserModel();

        userModel.setNome(newUser.getNome());
        userModel.setEmail(newUser.getEmail());

        Long userId = userRepository.save(userModel).getUserId();

        LoginModel loginModel = new LoginModel();

        loginModel.setLoginId(userId);
        loginModel.setSenha(newUser.getSenha());
        loginModel.setAuthenticator(newUser.getAuthenticator());

        loginRepository.save(loginModel);

        UserIdDTO userIdDTO = new UserIdDTO();

        userIdDTO.setUserId(userId);

        return userIdDTO;
    }

    public UserDTO findUser(Long userId) {

        UserModel userModel = userRepository.findById(userId).get();
        UserDTO user = new UserDTO();

        user.setUserId(userModel.getUserId());
        user.setNome(userModel.getNome());
        user.setEmail(userModel.getEmail());

        return user;
    }
}
