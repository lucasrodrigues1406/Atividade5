package br.com.fiap.buscheck.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserIdDTO {
    
    private Long userId;

}
