package br.com.fiap.buscheck.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.fiap.buscheck.model.LoginModel;

public interface LoginRepository extends JpaRepository<LoginModel, Long> { }