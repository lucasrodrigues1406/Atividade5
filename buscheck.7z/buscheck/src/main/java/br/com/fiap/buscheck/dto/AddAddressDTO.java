package br.com.fiap.buscheck.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddAddressDTO {

    private String tipo;
    private String logradouro;
    private Long numero;
    private String bairro;
    private String cidade;
    private String estado;
    private Long userId;
}
