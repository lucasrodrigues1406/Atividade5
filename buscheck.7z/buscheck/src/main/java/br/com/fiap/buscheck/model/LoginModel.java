package br.com.fiap.buscheck.model;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@Table(name = "tbl_login")
public class LoginModel {
    
    @Id
    private Long loginId;

    @Column(name = "senha")
    private String senha;

    @Column(name = "authenticator")
    private Boolean authenticator;
}
