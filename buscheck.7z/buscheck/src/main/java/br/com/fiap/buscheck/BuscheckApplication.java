package br.com.fiap.buscheck;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BuscheckApplication {

	public static void main(String[] args) {
		SpringApplication.run(BuscheckApplication.class, args);
	}

}
