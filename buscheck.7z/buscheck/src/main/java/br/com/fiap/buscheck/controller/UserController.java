package br.com.fiap.buscheck.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import br.com.fiap.buscheck.dto.SignupDTO;
import br.com.fiap.buscheck.dto.UserDTO;
import br.com.fiap.buscheck.dto.UserIdDTO;
import br.com.fiap.buscheck.service.UserService;
import io.swagger.v3.oas.annotations.tags.Tag;

@RestController
@RequestMapping(value = "/users")
@Tag(name = "Users", description = "Manutenção de usuários.")
public class UserController {
    
    @Autowired
    private UserService userService;

    @PostMapping
    public ResponseEntity<UserIdDTO> save(@RequestBody SignupDTO newCadastroDTO) {
        return ResponseEntity.ok().body(userService.save(newCadastroDTO));
    }

    @GetMapping(value = "/{userId}")
    @ResponseBody
    public ResponseEntity<UserDTO> findUser(@PathVariable Long userId) {
        return ResponseEntity.ok().body(userService.findUser(userId));
    }
}
