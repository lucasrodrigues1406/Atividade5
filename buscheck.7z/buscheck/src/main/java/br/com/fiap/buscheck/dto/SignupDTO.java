package br.com.fiap.buscheck.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SignupDTO {

    private String nome;
    private String email;
    private String senha;
    private Boolean authenticator;
}
