package br.com.fiap.buscheck.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import br.com.fiap.buscheck.model.AddressModel;

public interface AddressRepository extends JpaRepository<AddressModel, Long> {

    @Query(value = "SELECT * FROM tbl_endereco WHERE user_id = :userId", nativeQuery = true)
    List<AddressModel> findAddressByUserId(@Param("userId") Long userId);
}
