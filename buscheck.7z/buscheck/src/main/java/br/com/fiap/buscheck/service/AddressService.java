package br.com.fiap.buscheck.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.fiap.buscheck.dto.AddAddressDTO;
import br.com.fiap.buscheck.dto.AddressDTO;
import br.com.fiap.buscheck.dto.AddressIdDTO;
import br.com.fiap.buscheck.model.AddressModel;
import br.com.fiap.buscheck.repository.AddressRepository;

@Service
public class AddressService {
    
    @Autowired
    private AddressRepository addressRepository;

    public AddressIdDTO save(AddAddressDTO newAddress) {

        AddressModel addressModel = new AddressModel();

        addressModel.setTipo(newAddress.getTipo());
        addressModel.setLogradouro(newAddress.getLogradouro());
        addressModel.setNumero(newAddress.getNumero());
        addressModel.setBairro(newAddress.getBairro());
        addressModel.setCidade(newAddress.getCidade());
        addressModel.setUserId(newAddress.getUserId());

        AddressIdDTO addressIdDTO = new AddressIdDTO();

        addressIdDTO.setAddressId(addressRepository.save(addressModel).getAdreessId());

        return addressIdDTO;
    }

    public List<AddressDTO> findAll(Long userId) {

        List<AddressDTO> addresses = new ArrayList<>();
        System.out.println(userId);
        List<AddressModel> addressesModel = addressRepository.findAddressByUserId(userId);

        for(AddressModel addressModel : addressesModel) {
            
            AddressDTO address = new AddressDTO();

            address.setAddressId(addressModel.getAdreessId());
            address.setTipo(addressModel.getTipo());
            address.setLogradouro(addressModel.getLogradouro());
            address.setNumero(addressModel.getNumero());
            address.setBairro(addressModel.getBairro());
            address.setCidade(addressModel.getCidade());
            address.setCidade(addressModel.getCidade());

            addresses.add(address);
        }

        return addresses;
    }
}
