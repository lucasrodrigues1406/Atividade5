package br.com.fiap.buscheck.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.fiap.buscheck.dto.AddAddressDTO;
import br.com.fiap.buscheck.dto.AddressDTO;
import br.com.fiap.buscheck.dto.AddressIdDTO;
import br.com.fiap.buscheck.service.AddressService;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;


@RestController
@RequestMapping(value = "/address")
@Tag(name = "Users", description = "Manutenção de endereços.")
public class AddressController {
    
    @Autowired
    private AddressService addressService;

    @PostMapping
    @ResponseBody
    public ResponseEntity<AddressIdDTO> save(@RequestBody AddAddressDTO newAddress) {
        return ResponseEntity.ok().body(addressService.save(newAddress));
    }

    @GetMapping(value = "/{userId}")
    @ResponseBody
    public ResponseEntity<List<AddressDTO>> getMethodName(@PathVariable Long userId) {
        return ResponseEntity.ok().body(addressService.findAll(userId));
    }
}
