package br.com.fiap.buscheck;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuscheckApplicationTests {

	@Test
	void contextLoads() {
	}

}
